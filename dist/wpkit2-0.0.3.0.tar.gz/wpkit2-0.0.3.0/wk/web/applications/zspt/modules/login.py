
class LoginManager:
    def __init__(self,User,db):
        self.User=User
        self.db=db


