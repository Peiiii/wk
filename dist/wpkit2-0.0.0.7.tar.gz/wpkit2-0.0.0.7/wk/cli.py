
def main():
    words='Hello, I am wpkit ,use me !'
    length=50
    print('*'*length)
    print(words.center(length,'*'))
    print('*' * length)
